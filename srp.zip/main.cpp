/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

class Invoice {
public:
    Invoice(double amount) : amount(amount) {}
    double getAmount() const { return amount; }
private:
    double amount;
};

class InvoicePrinter {
public:
    void print(const Invoice& invoice) const {
        std::cout << "Total: " << invoice.getAmount() << std::endl;
    }
};

int main() {
    Invoice invoice(110.0);
    InvoicePrinter printer;
    printer.print(invoice);
    return 0;
}